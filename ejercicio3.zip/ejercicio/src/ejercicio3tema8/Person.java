package ejercicio3tema8;

public class Person {
    private int age;
    private String name;
    private int Phonenumber;


    public int getAge(){
        return age;
    }

    public void setAge(int age){
        this.age = age;

    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setName(String name) {
        this.name = name;
    }
}public String getName() {
    return name;
}

    






