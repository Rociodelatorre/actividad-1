package ejercicio1;

public class Parte1 {
    public static void main(String[] args) {
        int numero1 = 12;
        int numero2 = 14;
        int numero3 = 17;

        suma(numero1, numero2, numero3);



        int resultado = (numero1 + numero2 +numero3)
        System.out.println(resultado);

    }
    public static void suma(int numero1, int numero2, int numero3){
        int resultado = (numero1 + numero2 + numero3);
        System.out.println(resultado);
    }

}
package ejercicio1;
p
            }
        }
