package usages;

public enum Bucle {
}
