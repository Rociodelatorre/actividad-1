package Ejercicio2.tema4;

import usages.Bucle;

public class Ejercicio2 {
    public static void main(String[] args) {
        Object sistema_fuera_println = new Object(numeroIf(un, cero);
        Object sistemaFueraPrintln = sistema_fuera_println;

    }
Bucle WHILE
    public static void numeroIf (int un, Object cero){
        if (a>0)
        return (``Object positivo;);
        if (un==0)
        return; (``Object cero´´)

        return; ``ès negativo´´;

    }
public class main {
        public static void main(String[] args){
            int contador=10
                    while(contador>0){
                        System.out.println(contador);
                        contador= contador + 1;
                    }
}
Public static void bucleFor;
        public class Main{
            public static void main(String[] args) {
              for(int contador=1; contador<10; contador= contador + 1){
                  System.out.println(contador);

                }
            }
        }
    public  static  void  bucleDoWhile (){
        int  numero_while = 3 ;
       bucleDoWhile();{System.out.println( numero_while );
            numero_while ++;
        } while ( numero_while< 3 );



public class Main{
    public static void main(String[] args, Object verano) {
        var estación= verano;
        switch estación{
            case verano;
            System.out.println(``estación verano´´);
            break;
            var estación :Object invierno;
            Object = invierno;
            switch estación{
                case invierno;
                break 
                        var estación : Object otoño;
                switch estación{
                    case otoño;
                    System.out.println( ``estación otoño´´ );
                    break;
                    var estación: Object primavera;
                    switch estación{
                        case primavera;
                        System.out.println(``estación primavera´´);
                        break;
                    }
                }
                
            }
            
        }

    }
}
}
}
